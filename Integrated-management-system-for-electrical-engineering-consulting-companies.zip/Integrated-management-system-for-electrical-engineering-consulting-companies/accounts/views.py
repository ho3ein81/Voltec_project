from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.exceptions import AuthenticationFailed , NotFound
from rest_framework.generics import CreateAPIView , GenericAPIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from .serializers import (
    SignupSerializer , LoginSerializer , AccountSerializer
)
from .permissions import IsActiveUser , IsActiveProfile


class SignupView (CreateAPIView) :
    serializer_class = SignupSerializer


    def create(self, request, *args, **kwargs):
        response =  super().create(request, *args, **kwargs)

        return Response(
            {
                'success' : 'ثبت نام با موفقیت انجام شد'
            } , 
            status= status.HTTP_201_CREATED
        )


class LoginView (GenericAPIView) : 
    http_method_names = ['post']
    serializer_class = LoginSerializer


    def post (self , request) : 

        serializer = self.get_serializer(data = request.data)

        if serializer.is_valid() : 
            user = authenticate(
                request , 
                username = serializer.validated_data['national_id'] , 
                password = serializer.validated_data['password']
            )


            if not user : 
                raise AuthenticationFailed('کدملی یا رمزعبور نادرست می باشد')
            
            refresh = RefreshToken.for_user(user)


            return Response(
                {
                    'success' : 'ورود موفقیت آمیز' , 
                    'access_token' : str(refresh.access_token) , 
                    'refresh_token' : str(refresh) , 
                    'user_national_id' : serializer.validated_data['national_id']
                } , 
                status= status.HTTP_200_OK
            )


        return Response(
            {
                'error' : serializer.errors
            } , 
            status= status.HTTP_400_BAD_REQUEST
        )

    

class LogoutView (GenericAPIView) : 
    http_method_names = ['post']
    permission_classes = [IsAuthenticated , IsActiveUser , IsActiveProfile]

    def post (self , request) : 

        refresh_token = request.data.get('refresh')

        if not refresh_token : 
            return Response(
                {
                    'error' : 'refresh token ارسال نشده است'
                } , 
                status= status.HTTP_400_BAD_REQUEST
            )
        

        try : 
            refresh = RefreshToken(refresh_token)
            refresh.blacklist()
        
        except Exception : 
            return Response(
                {
                    'error' : 'توکن نامعتبر می باشد'
                } , 
                status= status.HTTP_400_BAD_REQUEST
            )
        
        else : 
            return Response(
                {
                    'success' : 'با موفقیت خارج شدید'
                } , 
                status= status.HTTP_200_OK
            )
            


class AccountView(GenericAPIView):
    http_method_names = ['get']
    permission_classes = [IsAuthenticated, IsActiveUser, IsActiveProfile]
    serializer_class = AccountSerializer

    def get(self, request):
        serializer = self.get_serializer(request.user)
        return Response(
            {
                'success': 'اطلاعات حساب با موفقیت دریافت شد',
                'account': serializer.data
            },
            status=status.HTTP_200_OK
        )

