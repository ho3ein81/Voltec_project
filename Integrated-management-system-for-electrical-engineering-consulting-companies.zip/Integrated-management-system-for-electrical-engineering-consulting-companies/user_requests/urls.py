from django.urls import path
from .views import (
    CompanyRegistrationRequestViewForRequester
)



urlpatterns = [
    #! درخواست های ثبت شرکت ====> List , Create
    path('company-registration-request/' , 
         CompanyRegistrationRequestViewForRequester.as_view(
            {
                'get' : 'list' , 
                'post' : 'create'
            }
         )
          , name= 'create_list_company_registration_request') ,

    #! درخواست های ثبت شرکت ====>  Update , Retrieve , Delete
    path('company-registration-request/<int:crr_id>/' , 
         CompanyRegistrationRequestViewForRequester.as_view(
            {
                'get' : 'retrieve' , 
                'patch' : 'partial_update' , 
                'delete' : 'destroy'     
            }
         )
          , name= 'retrieve_update_delete_company_registration_request')
]