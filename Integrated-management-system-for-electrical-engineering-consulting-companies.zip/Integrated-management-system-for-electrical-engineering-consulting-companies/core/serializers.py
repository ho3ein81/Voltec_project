from rest_framework import serializers
from .models import Province , City



class ProvincesListSerializer (serializers.ModelSerializer) : 
    class Meta : 
        model= Province
        fields = '__all__'


class CitiesListSerializer (serializers.ModelSerializer) : 
    class Meta : 
        model = City
        fields = '__all__'