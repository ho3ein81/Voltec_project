from django.contrib.auth.models import BaseUserManager



class UserManager(BaseUserManager):
    def create_user(self, national_id, phone, password=None, **extra_fields):
        if not national_id:
            raise ValueError("National ID is required")
        if not phone:
            raise ValueError("Phone is required")

        user = self.model(national_id=national_id, phone=phone, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, national_id, phone, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self.create_user(national_id, phone, password, **extra_fields)

