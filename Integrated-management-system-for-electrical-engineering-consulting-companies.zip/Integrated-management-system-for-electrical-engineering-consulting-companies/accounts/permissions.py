from rest_framework.permissions import BasePermission
from .models import Profile




class IsActiveUser (BasePermission) : 
    def has_permission(self, request, view):
        return request.user.is_active
    


class IsActiveProfile (BasePermission) :
    def has_permission(self, request, view):
        return Profile.objects.filter(
            user = request.user , 
            status = Profile.StatusField.ACTIVE
        ).exists()