from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    ordering = ('national_id',)
    list_display = ('national_id', 'phone', 'first_name', 'last_name', 'is_active', 'is_staff')
    list_filter = ('is_active', 'is_staff', 'is_superuser')
    search_fields = ('national_id', 'phone', 'first_name', 'last_name')

    fieldsets = (
        (None, {'fields': ('national_id', 'password')}),
        ('اطلاعات شخصی', {'fields': ('first_name', 'last_name', 'phone')}),
        ('دسترسی‌ها', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('تاریخ‌ها', {'fields': ('last_login', 'date_joined')}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('national_id', 'phone', 'password1', 'password2', 'is_staff', 'is_active'),
        }),
    )

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        if 'date_joined' in form.base_fields:
            form.base_fields['date_joined'].label = 'تاریخ عضویت'
        if 'last_login' in form.base_fields:
            form.base_fields['last_login'].label = 'آخرین ورود'
        if 'is_active' in form.base_fields:
            form.base_fields['is_active'].label = 'فعال'
        if 'is_staff' in form.base_fields:
            form.base_fields['is_staff'].label = 'کارمند'
        if 'is_superuser' in form.base_fields:
            form.base_fields['is_superuser'].label = 'ادمین'
        return form