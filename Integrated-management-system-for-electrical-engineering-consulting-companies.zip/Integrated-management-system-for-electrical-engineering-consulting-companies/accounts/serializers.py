from rest_framework import serializers
from .models import User


class SignupSerializer (serializers.ModelSerializer) : 
    
    class Meta : 
        model = User
        fields = [
            'first_name' , 'last_name' , 'national_id' , 'phone' , 'email' , 'password' , 
            'confirm_password'
        ]
    
    confirm_password = serializers.CharField(write_only = True)

    def validate_first_name (self, value : str) :

        value = value.strip()


        if not all(i.isalpha() or i.isspace() for i in value)  :
            raise serializers.ValidationError('لطفا یک نام معتبر وارد کنید')

        return value


    def validate_last_name (self , value : str) : 

        value = value.strip()


        if not all(i.isalpha() or i.isspace() for i in value) : 
            raise  serializers.ValidationError('لطفا یه نام خانوادکی معتبر وارد کنید')
        
        return value
    

    def validate_national_id (self , value : str) : 

        value = value.strip()


        if len(value) != 10 : 
            raise serializers.ValidationError('کدملی وارد شده ده رقمی نمی باشد')
        

        if not value.isdigit() :
            raise serializers.ValidationError('کدملی نادرست می باشد')
        

        return value
    

    def validate_phone (self , value : str)  :

        value = value.strip()


        if not value.startswith('0') : 
            raise serializers.ValidationError('شماره همراه باید با صفر شروع شود')
        
        if len(value) != 11  :
            raise serializers.ValidationError('شماره همراه نادرست می باشد')
        

        if not value.isdigit() : 
            raise serializers.ValidationError('شماره همراه نادرست می باشد')
        
        return value
    

    def validate_password (self , value : str) : 

        value = value.strip()


        if len(value) < 8 :
            raise serializers.ValidationError('حداقل کاراکترهای رمزعبور باید هشت تا باشد')
        

        if not any(i.isupper() for i in value) : 
            raise serializers.ValidationError('رمزعبور باید شامل حروف بزرگ انگلیسی شد')
        
        if not any(i.islower() for i in value) : 
            raise serializers.ValidationError('رمزعبور باید شامل حروف کوچک انگلیسی باشد')
        

        if not any(i.isdigit() for i in value) : 
            raise serializers.ValidationError('رمزعبور باید شامل اعداد باشد')
        
        if not any(i in ['@' , '&' , '%' , '#' , '!' , '?'] for i in value) : 
            raise serializers.ValidationError('رمزعبور باید شامل سمبل ها باشد')
        

        return value
    


    def validate(self, attrs):
        values =  super().validate(attrs)


        password = values.get('password')
        confirm_password = values.get('confirm_password')


        if password != confirm_password : 
            raise serializers.ValidationError('رمزعبور با تایید رمزعبور یکسان نیستند')
        
        return values
    

    def create(self, validated_data):
        validated_data.pop('confirm_password', None)
        password = validated_data.pop('password')

        user = User.objects.create_user(
            **validated_data,
            password=password
        )
        return user






class LoginSerializer (serializers.Serializer) : 
    
    national_id = serializers.CharField()

    password = serializers.CharField(write_only = True)


class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            'first_name',
            'last_name',
            'national_id',
            'phone',
            'email',
        ]
        read_only_fields = fields