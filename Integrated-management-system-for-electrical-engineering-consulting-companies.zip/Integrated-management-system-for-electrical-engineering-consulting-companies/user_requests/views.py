from django.shortcuts import get_object_or_404
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from accounts.permissions import IsActiveUser , IsActiveProfile
from tenants.models import CompanyRegistrationRequest
from .serializers import (
    CreateCompanyRegistrationRequestSerializer , ListCompanyRegistrationRequestSerializer, 
    RetrieveCompanyRegistrationRequestSerializer , UpdateCompanyRegistrationRequestSerializer
)
from .permissions import (
    IsPendingCompanyRegistrationRequest
)

class CompanyRegistrationRequestViewForRequester (viewsets.ModelViewSet) : 

    def get_permissions(self):

        if self.action in ['create' , 'list' , 'retrieve'] : 
            return [IsAuthenticated() , IsActiveUser() , IsActiveProfile()]
        
        if self.action in ['partial_update' , 'destroy'] : 
            return [IsAuthenticated() , IsActiveUser() , IsActiveProfile() , IsPendingCompanyRegistrationRequest()]
        
        return super().get_permissions()
    

    def get_serializer_class(self):

        if self.action == 'create' : 
            return CreateCompanyRegistrationRequestSerializer
        
        if self.action == 'list' : 
            return ListCompanyRegistrationRequestSerializer
        
        if self.action == 'retrieve' : 
            return RetrieveCompanyRegistrationRequestSerializer
        
        if self.action == 'partial_update' : 
            return UpdateCompanyRegistrationRequestSerializer

        return super().get_serializer_class()
    

    def get_queryset(self):
        
        qs = CompanyRegistrationRequest.objects.filter(
            requester = self.request.user
        ).order_by('-created_at')


        return qs
    

    def get_object(self):
        
        return get_object_or_404(
            CompanyRegistrationRequest , 
            pk = self.kwargs['crr_id'] , 
            requester = self.request.user
        )