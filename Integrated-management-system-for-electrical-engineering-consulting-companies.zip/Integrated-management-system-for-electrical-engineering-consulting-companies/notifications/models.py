from django.db import models
from accounts.models import User



class Notification (models.Model) :

    sender = models.ForeignKey(
        User , 
        on_delete= models.SET_NULL , 
        null= True , 
        blank= True , 
        verbose_name= 'فرستنده' , 
        related_name= 'sent_notifications'
    )

    receptor = models.ForeignKey(
        User , 
        on_delete= models.SET_NULL , 
        null= True , 
        blank= True , 
        related_name= 'receives_notifications' , 
        verbose_name= 'دریافت کننده'
    )

    title = models.CharField(
        max_length= 150, 
        verbose_name= 'عنوان'
    )

    message = models.TextField(
        verbose_name= 'متن'
    )

    created_at = models.DateTimeField(
        auto_now_add= True , 
        verbose_name= 'زمان ارسال'
    )

    is_read = models.BooleanField(
        default= False , 
        verbose_name= 'وضعیت خواندن'
    )

    class Meta : 
        verbose_name = 'اعلان'
        verbose_name_plural = 'اعلانات'

