from rest_framework import serializers
from tenants.models import CompanyRegistrationRequest



class CreateCompanyRegistrationRequestSerializer (serializers.ModelSerializer) : 
    class Meta : 
        model = CompanyRegistrationRequest
        fields = [
            'company_name'  , 'company_national_id' , 'company_description' , 
            'company_registration_number' , 'type_company' , 'company_province' , 
            'company_city'
        ]

    def validate_company_national_id (self , value : str) : 

        value = value.strip()

        if not value.isdigit() : 
            raise serializers.ValidationError('شناسه یکتا باید فقط حاوی ارقام باشد')
        
        if len(value) != 11 : 
            raise serializers.ValidationError('شناسه یکتا باید 11 رقم باشد')

        return value
    
    def validate_company_registration_number (self , value : str) : 

        if not value.isdigit() : 
            raise serializers.ValidationError('شماره ثبت باید فقط حاوی ارقام باشد')
        

        return value
    
    def create(self, validated_data):
        new_request = CompanyRegistrationRequest.objects.create(
            requester = self.context['request'].user , 
            **validated_data

        )

        return new_request
    

class ListCompanyRegistrationRequestSerializer (serializers.ModelSerializer) : 
    class Meta : 
        model = CompanyRegistrationRequest
        fields = [
            'created_at' , 'company_name' , 'type_company' , 'status'
        ]


class RetrieveCompanyRegistrationRequestSerializer (serializers.ModelSerializer) : 
    class Meta : 
        model = CompanyRegistrationRequest
        fields = [
            'created_at' , 'reviewed_at' , 'company_name' , 'company_national_id' , 
            'company_description' , 'company_registration_number' , 'type_company' , 
            'company_province' , 'company_city' , 'status' , 'reject_reason'
        ] 


class UpdateCompanyRegistrationRequestSerializer (serializers.ModelSerializer) : 
    class Meta : 
        model = CompanyRegistrationRequest
        fields = [
            'company_name'  , 'company_national_id' , 'company_description' , 
            'company_registration_number' , 'type_company' , 'company_province' , 
            'company_city'
        ]

    def validate_company_national_id (self , value : str) : 

        value = value.strip()

        if not value.isdigit() : 
            raise serializers.ValidationError('شناسه یکتا باید فقط حاوی ارقام باشد')
        
        if len(value) != 11 : 
            raise serializers.ValidationError('شناسه یکتا باید 11 رقم باشد')

        return value
    
    def validate_company_registration_number (self , value : str) : 

        if not value.isdigit() : 
            raise serializers.ValidationError('شماره ثبت باید فقط حاوی ارقام باشد')
        

        return value
    
    