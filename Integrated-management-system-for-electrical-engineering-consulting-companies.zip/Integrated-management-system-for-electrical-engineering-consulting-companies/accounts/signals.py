from django.dispatch import receiver
from django.db.models.signals import post_save
from django.db import transaction
from django.contrib.auth.models import Group
from .models import User , Profile
from notifications.models import Notification




@receiver(post_save , sender= User)
def after_signup (sender , instance , created , **kwargs) :

    if created : 
    
        with transaction.atomic() : 

            #! Add to members group

            members_group = Group.objects.filter(name = 'members').first()

            if members_group : 
                instance.groups.add(members_group)

            #! Create Profile

            Profile.objects.create(
                user = instance 
            )


            #! Send Notification

            Notification.objects.create(
                sender = None , 
                receptor = instance , 
                title = 'ثبت نام موفقیت آمیز' , 
                message = 'خوش آمدید! حساب کاربری شما با موفقیت ایجاد شد. امیدواریم از خدمات ما نهایت استفاده را ببرید.'
            )



            



        
