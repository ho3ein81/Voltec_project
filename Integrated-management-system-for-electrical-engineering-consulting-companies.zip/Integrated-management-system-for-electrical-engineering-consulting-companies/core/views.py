from rest_framework.generics import ListAPIView
from rest_framework.exceptions import NotFound
from .models import Province
from .serializers import (
    ProvincesListSerializer , CitiesListSerializer
)

class ProvincesListView (ListAPIView) : 

    serializer_class = ProvincesListSerializer

    def get_queryset(self):
        

        qs = Province.objects.all()


        #! Search By name
        search_name = self.request.GET.get('search_name')

        if search_name : 
            qs = qs.filter(
                name__icontains = search_name
            )


        return qs



class CitiesListView (ListAPIView) :

    serializer_class = CitiesListSerializer

    def get_province (self) : 

        province = Province.objects.filter(
            pk = self.kwargs['province_id']
        ).first()


        if not province : 
            raise NotFound('استانی یافت نشد')
        

        return province
    

    def get_queryset(self):
        
        province = self.get_province()
        qs = province.cities.all()


        return qs


