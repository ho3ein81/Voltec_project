from rest_framework.permissions import BasePermission
from tenants.models import CompanyRegistrationRequest



class IsPendingCompanyRegistrationRequest (BasePermission) :

    def has_object_permission(self, request, view, obj):
        
        return obj.status == CompanyRegistrationRequest.StatusField.PENDING