from django.db import models
from django.contrib.auth.models import AbstractUser
from .managers import UserManager

class User (AbstractUser) : 
    username = None

    national_id = models.CharField(
        max_length= 10 , 
        verbose_name= 'کدملی' ,  
        unique= True
    )

    phone = models.CharField(
        max_length= 11 , 
        verbose_name= 'شماره همراه'  , 
        unique= True
    )

    email = models.EmailField(
        verbose_name= 'آدرس ایمیل' , 
        unique= True
    )
    
    objects = UserManager()
    USERNAME_FIELD = 'national_id'
    REQUIRED_FIELDS = ['phone']

    def __str__(self):
        return self.national_id
    
    class Meta :
        verbose_name = 'کاربر'
        verbose_name_plural = 'کاربران'




class Profile (models.Model) : 
    class StatusField (models.TextChoices) : 
        ACTIVE = 'active' , 'فعال'
        INACTIVE = 'inactive' , 'غیرفعال'

    user = models.OneToOneField(
        User , 
        on_delete= models.CASCADE , 
        related_name= 'profile' , 
        verbose_name= 'دارنده ی پروفایل'
    )


    created_at = models.DateTimeField(
        auto_now_add= True , 
        verbose_name= 'زمان ایجاد'
    )

    status = models.CharField(
        max_length= 10 , 
        verbose_name= 'وضعیت پروفایل' , 
        choices= StatusField.choices , 
        default= StatusField.ACTIVE
    )

    class Meta : 
        verbose_name = 'پروفایل'
        verbose_name_plural = 'پروفایل ها'

