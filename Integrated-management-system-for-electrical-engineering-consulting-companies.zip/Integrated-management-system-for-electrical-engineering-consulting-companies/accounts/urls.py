from django.urls import path
from .views import (
    SignupView , LoginView , LogoutView , AccountView
)


urlpatterns = [
    #! signup
    path('signup/' , SignupView.as_view() , name= 'signup') , 
    #! login
    path('login/' , LoginView.as_view() , name= 'login') , 
    #! Logout
    path('logout/' , LogoutView.as_view() , name= 'logout'),
    #! Account
    path('account/', AccountView.as_view(), name='account')

]