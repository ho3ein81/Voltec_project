from django.db import models



class Province (models.Model) :

    name = models.CharField(
        verbose_name= 'نام استان' , 
        max_length= 150
    )


    def __str__(self):
        return self.name



class City (models.Model) : 
    
    name= models.CharField(
        verbose_name= 'نام شهر' , 
        max_length= 150
    )

    province = models.ForeignKey(
        Province , 
        verbose_name= 'استان' , 
        on_delete= models.CASCADE , 
        related_name= 'cities'
    )


    def __str__(self):
        return self.name