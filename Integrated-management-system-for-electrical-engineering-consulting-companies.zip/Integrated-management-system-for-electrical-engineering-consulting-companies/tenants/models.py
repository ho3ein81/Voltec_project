from django.db import models
from accounts.models import User
from core.models import Province , City


class CompanyRegistrationRequest (models.Model) : 
    class CompanyType(models.TextChoices):
        PUBLIC_JOINT_STOCK = 'public_joint_stock', 'سهامی عام'
        PRIVATE_JOINT_STOCK = 'private_joint_stock', 'سهامی خاص'
        LLC = 'llc', 'مسئولیت محدود'
        SOLIDARITY = 'solidarity', 'تضامنی'
        PROPORTIONAL = 'proportional', 'نسبی'
        MIXED_JOINT_STOCK = 'mixed_joint_stock', 'مختلط سهامی'
        MIXED_NON_JOINT_STOCK = 'mixed_non_joint_stock', 'مختلط غیرسهامی'
        COOPERATIVE = 'cooperative', 'تعاونی'
    
    class StatusField (models.TextChoices) : 
        PENDING = 'pending' , 'در حال بررسی' 
        APPROVED = 'approved' , 'تایید شده'
        REJECTED = 'rejected'  , 'تایید نشده'

    requester = models.ForeignKey(
        User , 
        on_delete= models.SET_NULL , 
        null= True , 
        blank= True  , 
        verbose_name= 'درخواست کننده' , 
        related_name= 'send_companyrequest'
    )

    created_at = models.DateTimeField(
        auto_now_add= True , 
        verbose_name= 'زمان ثبت'
    )

    reviewer = models.ForeignKey(
        User , 
        on_delete= models.SET_NULL , 
        null= True , 
        blank= True , 
        verbose_name= 'بررسی کننده' ,
        related_name= 'reviews_companyrequest'
    )

    reviewed_at = models.DateTimeField(
        null= True , 
        blank= True , 
        verbose_name= 'زمان بررسی'
    )

    company_name = models.CharField(
        max_length= 350 , 
        verbose_name= 'نام شرکت'
    )

    company_national_id = models.CharField(
        max_length= 11 , 
        unique= True , 
        verbose_name= 'شناسه یکتا'
    )

    company_description = models.TextField(
        verbose_name= 'درباره ی شرکت'
    )

    
    company_registration_number = models.CharField(
        max_length= 20 , 
        unique= True , 
        verbose_name= 'شماره ثبت'
    )


    type_company = models.CharField(
        max_length= 50 , 
        verbose_name= 'نوع شرکت' , 
        choices= CompanyType.choices
    )

    company_province = models.ForeignKey(
        Province , 
        on_delete= models.SET_NULL , 
        null= True , 
        blank= True , 
        verbose_name= 'استان'
    )

    company_city = models.ForeignKey(
        City , 
        on_delete= models.SET_NULL , 
        null= True , 
        blank= True , 
        verbose_name= 'شهر'  
    )

    status = models.CharField(
        max_length= 15 , 
        choices= StatusField.choices , 
        default= StatusField.PENDING , 
        verbose_name= 'وضعیت درخواست'
    )

    reject_reason = models.TextField(
        verbose_name= 'دلیل رد' , 
        null= True , 
        blank= True
    )


    class Meta : 
        verbose_name = 'درخواست ثبت شرکت'
        verbose_name_plural =  'درخواست های ثبت شرکت'





