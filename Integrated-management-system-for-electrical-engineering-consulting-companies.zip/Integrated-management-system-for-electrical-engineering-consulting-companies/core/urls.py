from django.urls import path
from .views import (
    ProvincesListView , CitiesListView
)


urlpatterns = [
    #! Provinces List
    path('provinces/' , ProvincesListView.as_view() , name= 'provinces_list') , 
    #! Cities List
    path('cities/<int:province_id>/' , CitiesListView.as_view() , name= 'cities_list')
]