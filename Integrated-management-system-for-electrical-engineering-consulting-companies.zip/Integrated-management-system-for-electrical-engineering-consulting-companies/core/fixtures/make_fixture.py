import json

with open("core/fixtures/iran.json", encoding="utf-8") as f:
    data = json.load(f)

fixture = []

province_id = 1
city_id = 1

for province_name, cities in data.items():

    fixture.append({
        "model": "core.province",
        "pk": province_id,
        "fields": {
            "name": province_name
        }
    })

    for city_name in cities:
        fixture.append({
            "model": "core.city",
            "pk": city_id,
            "fields": {
                "name": city_name,
                "province": province_id
            }
        })
        city_id += 1

    province_id += 1

with open("core/fixtures/fixture.json", "w", encoding="utf-8") as f:
    json.dump(fixture, f, ensure_ascii=False, indent=2)
